Supporting dataset for:

On the impact of varying region proposal strategies for raindrop detection and classification using convolutional neural networks 
(Guo, Akcay, Adey and Breckon), In Proc. International Conference on Image Processing IEEE, 2018.

@InProceedings{guo18raindrop,
  author =     {Guo, T. and Akcay, S. and Adey, P. and Breckon, T.P.},
  title =      {On the impact of varying region proposal strategies for raindrop detection and classification using convolutional neural networks},
  booktitle =  {Proc. International Conference on Image Processing},
  pages =      {1-5},
  year =       {2018},
  month =      {September},
  publisher =  {IEEE},
  keywords =   {rain detection, raindrop distortion, all-weather computer vision, automotive vision, CNN},
}

_________________

The dataset provides JPEG (jpg) images of raindrops and non raindrop examples. These are captured from a range of sources
and includes data from the earlier work by [Webster/Breckon 2015] as a subset.
_________________
