This dataset is based on the Webster dataset.

Additional to the Webster dataset, there are training and testing images of 
tree branches and road signs in order to increase the performance of raindrop 
classification based on CNN.