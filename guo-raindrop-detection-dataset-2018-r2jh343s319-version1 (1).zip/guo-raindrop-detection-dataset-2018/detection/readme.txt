The images are prepared for raindrop detection testing. 

The ground truth label contains the xml file that stores the 
ground truth location of the raindrops in each associated image.

e.g.

image-00001.jpg <-> ground-truth-00001.xml
image-00002.jpg <-> ground-truth-00002.xml
etc.
